/*
 ##########################################################
## This script is copyrighted to ArcadeBooster.com and you
## are free to modify the script but duplication, selling
## or transferring of this script is a violation of the
## copyright and purchase agreement.
##
## File Name: en-US.js
## Version : 1.5.7.4
## Date : 2015-06-04   18:43:58
##########################################################
 */
(function ($) {
	'use strict';

	$.sceditor.locale["en-US"] = {
		dateFormat: "month/day/year"
	}
})(jQuery);