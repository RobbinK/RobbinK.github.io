<?php
/*
 ##########################################################
## This script is copyrighted to ArcadeBooster.com and you
## are free to modify the script but duplication, selling
## or transferring of this script is a violation of the
## copyright and purchase agreement.
##
## File Name: booter.php
## Version : 1.5.7.4
## Date : 2015-06-04   18:43:58
##########################################################
 */


require_once('pengu_pagination/pengu_pagination.class.php');
require_once('pengu_comment/pengu_comment.class.php');
require_once('tinymce/tinymce.class.php');
require_once('pengu_message/message.class.php');
require_once('pengu_image/pengu_image.class.php');
require_once('mail/booter.php');
require_once('i18n/booter.php');