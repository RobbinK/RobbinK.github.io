 <?php
 class Rate extends Model
 {
     protected $_table="abs_games_rate";
 }     
 